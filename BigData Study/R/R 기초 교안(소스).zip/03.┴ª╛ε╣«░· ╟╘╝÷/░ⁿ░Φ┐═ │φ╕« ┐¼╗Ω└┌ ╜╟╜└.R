# 다음 2개의 변수를 이용하여 관계 연산 테스트를 수행하시오.
num1 <- 14
num2 <- 5

result <- num1 == num2
result

result <- num1 != num2
result

result <- num1 > num2
result

result <- num1 < num2
result

result <- num1 >= num2
result

result <- num1 <= num2
result

result <- num1 >= 10 & num2 < 3
result

result <- num1 >= 10 | num2 < 3
result

result <- !(num1 >= 10) | num2 < 3
result


# 추가 문제
data1 <- 'a'
data2 <- 'b'

# 소괄호를 이용하면 실행과 동시에 출력이 가능하다.
(data1 >= data2)
(data1 < data2)
su1 <- 3
su2 <- 2
(su1 >= su2)
(su1 < su2)
(su1 == su2)
(su1 != su2)