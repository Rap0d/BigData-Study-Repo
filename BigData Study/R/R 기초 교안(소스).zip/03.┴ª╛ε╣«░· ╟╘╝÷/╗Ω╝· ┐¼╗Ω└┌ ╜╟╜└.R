# 다음 2개의 변수를 이용하여 산술 연산 테스트를 수행하시오.

num1 <- 14
num2 <- 5

result <- num1 + num2
result

result <- num1 - num2
result

result <- num1 * num2
result

result <- num1 / num2
result

result <- num1 %% num2
result

result <- num1 ^ 2
result

result <- num2 ** 3
result