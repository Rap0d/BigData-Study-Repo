package controller;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.CheckBox;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class CheckBoxTestController implements Initializable {
	@FXML private CheckBox apple ;
	@FXML private CheckBox grape ;
	@FXML private CheckBox orange ;
	@FXML private ImageView imgApple ;
	@FXML private ImageView imgGrape ;
	@FXML private ImageView imgOrange ;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		apple.setOnAction(event -> handleButton(event));
		grape.setOnAction(event -> handleButton(event));
		orange.setOnAction(event -> handleButton(event));
	}
	public void handleButton(ActionEvent event) {
		Object who = event.getSource() ;
		if ( who instanceof CheckBox ) {
			if ( who == apple) {
				if (apple.isSelected()) {
					imgApple.setImage(getImageInfo("apple.jpg"));	
				} else {
					imgApple.setImage(getImageInfo("noimage.jpg"));
				}				
			} else if ( who == grape) {
				if (grape.isSelected()) {
					imgGrape.setImage(getImageInfo("grape.gif"));	
				} else {
					imgGrape.setImage(getImageInfo("noimage.jpg"));
				}
			} else if ( who == orange) {
				if (orange.isSelected()) {
					imgOrange.setImage(getImageInfo("orange.gif"));	
				} else {
					imgOrange.setImage(getImageInfo("noimage.jpg"));
				}
			}	
		}
	}
	private Image getImageInfo(String imgname) {
		String name = "/application/images/" + imgname ; 
		String url = getClass().getResource(name).toString();
		return new Image(url);
	}
}