package schoolBasic;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;
import model.Member;

public class ChartBarController implements Initializable{
	@FXML private BarChart<String, Integer> barChart;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		System.out.println( this.getClass() + ":initialize()");
	}
	public void makeChart(Member member) { //�Ѹ��� ���� ���� �׷����� �׷� �ִ� �޼ҵ�
		System.out.println( this.getClass() + ":makeChart()");
		System.out.println( member );
		
		List<XYChart.Data<String, Integer>> lists = new ArrayList<XYChart.Data<String, Integer>>() ;
		
		lists.add( new XYChart.Data<String, Integer>("����", member.getKor())) ;
		lists.add( new XYChart.Data<String, Integer>("����", member.getEng())) ;
		lists.add( new XYChart.Data<String, Integer>("����", member.getMath())) ;
		
		XYChart.Series<String, Integer> series1 = new XYChart.Series<String, Integer>();
		series1.setName( member.getName() );       
		series1.setData(FXCollections.observableArrayList(
			lists
		));  
		barChart.getData().add(series1);
		
		barChart.setTitle( "\'" + member.getName() + "(" + member.getId() + ")\'�� ����ǥ");
	}
	public void makeChartAllData(ObservableList<Member> dataLists) {
		System.out.println( this.getClass() + ":makeChartAllData()");
		//��ü�� ���� ���� �׷���
		barChart.setTitle( "��ü �л����� ����ǥ");
		barChart.setPrefHeight(1000);
		barChart.setPrefWidth(1000);
		
		for(Member member : dataLists) {
			List<XYChart.Data<String, Integer>> lists = new ArrayList<XYChart.Data<String, Integer>>() ;
			
			lists.add( new XYChart.Data<String, Integer>("����", member.getKor())) ;
			lists.add( new XYChart.Data<String, Integer>("����", member.getEng())) ;
			lists.add( new XYChart.Data<String, Integer>("����", member.getMath())) ;
			
			XYChart.Series<String, Integer> series = new XYChart.Series<String, Integer>();
			series.setName( member.getName() );       
			series.setData(FXCollections.observableArrayList(
				lists
			));  
			barChart.getData().add(series);			
		}		
	}
}