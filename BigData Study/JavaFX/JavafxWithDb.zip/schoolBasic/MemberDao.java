package schoolBasic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.List;

import model.Member;
import model.MemberType;

public class MemberDao {    
    private String driver;
    private String url;
    private String id;
    private String password;
    private int totalcount;
    
    ArrayList<Member> lists = new ArrayList<Member>();
    
    public MemberDao() {
    	driver  = "oracle.jdbc.driver.OracleDriver" ;
		url  = "jdbc:oracle:thin:@localhost:1521:xe" ;
		id = "jindori" ;
		password = "oracle" ;
		
		fillData();
	}
    private void fillData() {
    	lists.add(new Member("�踻��", "������", 50, 60, 70, MemberType.STUDENET, "2019/08/15", null)) ;
		for (int i = 1; i <= 10; i++) {
			lists.add(new Member("hong" + i, "ȫ�л�", 50, 60, 70, MemberType.STUDENET, "2019/08/15", "child01.jpg")) ;
			lists.add(new Member("kim" + i, "���л�", 60, 70, 80, MemberType.STUDENET, "2000/07/17", "child02.jpg")) ;
			lists.add(new Member("lee" + i, "�̰���", 40, 50, 60, MemberType.TEACHER, null, "child03.jpg")) ;
			lists.add(new Member("an" + i, "�Ȱ���", 30, 40, 50, MemberType.TEACHER, null, "child04.jpg")) ;
			lists.add(new Member("choi" + i, "������", 40, 50, 60, MemberType.STAFF, null, null)) ;
			lists.add(new Member("son" + i, "������", 30, 40, 50, MemberType.STAFF, null, null)) ;
			lists.add(new Member("im" + i, "���Ϸ�", 40, 50, 60, MemberType.TEACHER, null, null)) ;
			lists.add(new Member("sim" + i, "������", 30, 40, 50, MemberType.TEACHER, null, null)) ;
			lists.add(new Member("yoon" + i, "������", 40, 50, 60, MemberType.STAFF, null, null)) ;
			lists.add(new Member("seol" + i, "������", 30, 40, 50, MemberType.STAFF, null, null)) ;
		}
		System.out.println( "lists.size() : " + lists.size());	
		this.totalcount = lists.size() ;
		System.out.println( "totalcount : " + totalcount);
	}
    
	public int getTotalcount() {
		return totalcount;
	}
	private Connection getConnection() { //������ ���̽� ���� ��ü
    	Connection conn = null;
        try {
		    Class.forName( driver );
		    conn = DriverManager.getConnection( url, id, password );
		    System.out.println("Ŀ�ؼ� �� ���� üũ");
		    System.out.println( conn == null );
        } catch (Exception e) {
        	e.printStackTrace();
			//System.out.println("Exception: " + e.toString());
        }
        return conn;
    }
	 
    public int insertData(Member bean){
    	System.out.println("DB�� �μ�Ʈ�Ѵ�.");			
        System.out.println( this.getClass() + " : " + bean );		
		return 0 ;
    }
    

	public List<Member> getAllData(int beginRow, int endRow) {
		return lists.subList(beginRow, endRow);
	}
    

	public int updateData(Member bean) {
		System.out.println( this.getClass() + ":" + bean );
		return 0 ;
	}
	public int deleteData( String id ) {
		System.out.println("������ ���̵� : " + id );
		return 0 ;
	}

}