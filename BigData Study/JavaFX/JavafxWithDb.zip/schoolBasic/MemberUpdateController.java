package schoolBasic;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Member;
import model.MemberType;
import utility.Utility;

public class MemberUpdateController implements Initializable {
	@FXML private TextField tfId ;
	@FXML private TextField tfName ;
	@FXML private TextField tfKor ;
	@FXML private TextField tfEng ;
	@FXML private TextField tfMath ;
	@FXML private ComboBox<String> comboType ;
//	@FXML private TextField tfBirth ;
	@FXML private DatePicker dateBirth; 	
	
	private Member bean ;
	

	@Override
	public void initialize(URL location, ResourceBundle resources) {
	}

	public void onMemberUpdate(ActionEvent event) {
        String id = tfId.getText().trim();
        String name = tfName.getText().trim();
        int kor = Integer.valueOf(tfKor.getText().trim());
        int eng = Integer.valueOf(tfEng.getText().trim());
        int math = Integer.valueOf(tfMath.getText().trim());
        int type = comboType.getSelectionModel().getSelectedIndex();        
        
        MemberType memtype = Utility.getMemType(type) ;        
//        String birth = tfBirth.getText().trim();
        String birth = dateBirth.getValue().toString().replace("-", "/");
        
        Member bean = new Member(id, name, kor, eng, math, memtype, birth, null);        
        
//        System.out.println( this.getClass() + " : " + ( lists == null) );
//        lists.add(bean);
        
        MemberDao dao = new MemberDao();
        dao.updateData(bean) ;
        
        this.lists.remove( this.updatedIndex ) ;
        
        lists.add(this.updatedIndex, bean ) ; //����� �������Ƿ� �ٽ� �߰���
        
        closeStage(event);
	}
    private void closeStage(ActionEvent event) {
        Node source = (Node)event.getSource(); 
        Stage stage = (Stage)source.getScene().getWindow();
        stage.close();
    }	

    private int updatedIndex = - 1 ; //������ ���� ��ȣ
    
	public void setBean( Member bean, int idx) {
		//idx : ����Ʈ ����� �ε��� ��ȣ
		System.out.println(this.getClass() + ":" + bean );
		this.bean = bean ;
		this.updatedIndex = idx ;		
		tfId.setEditable(false);
		tfId.setDisable(false);
		fillData() ;
	}

	private void fillData() {
		tfId.setText( this.bean.getId() );
		tfName.setText( this.bean.getName() );
		tfKor.setText( String.valueOf( this.bean.getKor()));
		tfKor.setText( String.valueOf( this.bean.getKor()));
		tfEng.setText( String.valueOf( this.bean.getEng()));
		tfMath.setText( String.valueOf( this.bean.getMath()));
		comboType.setValue( this.bean.getMemtype());
		
		String birth = this.bean.getBirth() ;
		if ( birth != null ) {			   
			System.out.println( birth);
	        dateBirth.setValue(Utility.getDatePicker( birth ));			
		}			
	}

	private ObservableList<Member> lists;
	
	public void setObservableList(ObservableList<Member> lists) {
		this.lists = lists ;	
		
	}
}