package schoolBasic;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.PieChart;
import model.Member;

public class ChartPieController implements Initializable{
	@FXML private PieChart pieChart;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		System.out.println( this.getClass() + ":initialize()");
	}
	public void xxx(ActionEvent e) {
		
	}
	public void makePieChart(Member member) {
		System.out.println( this.getClass() + ":setData()");
		System.out.println( member );
		
		List<PieChart.Data> lists = new ArrayList<PieChart.Data>() ;
		
		lists.add( new PieChart.Data("����", member.getKor())) ;
		lists.add( new PieChart.Data("����", member.getEng())) ;
		lists.add( new PieChart.Data("����", member.getMath())) ;
		
		pieChart.setData(FXCollections.observableArrayList(
				lists
		));		
		
		pieChart.setTitle( "\'" + member.getName() + "\'�� ����ǥ");
	}
}