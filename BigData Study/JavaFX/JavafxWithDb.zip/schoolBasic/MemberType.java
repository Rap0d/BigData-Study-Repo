package schoolBasic;

public enum MemberType {
	//0:�л�, 1:����, 2:����
	STUDENET("�л�", 0), TEACHER("����", 1), STAFF("����", 2) ;
    
    private String name ;
    private int type ;
    
    private MemberType(String name, int type){
        this.name = name ;
        this.type = type; 
    }
    public String getName(){
        return name ;
    }
	public int getType() {
		return type;
	}    
}
