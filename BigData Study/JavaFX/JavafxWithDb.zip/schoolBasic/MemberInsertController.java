package schoolBasic;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Member;
import model.MemberType;
import utility.Utility;

public class MemberInsertController implements Initializable {
	@FXML private TextField tfId ;
	@FXML private TextField tfName ;
	@FXML private TextField tfKor ;
	@FXML private TextField tfEng ;
	@FXML private TextField tfMath ;
	@FXML private ComboBox<String> comboType ;
//	@FXML private TextField tfBirth ;
	@FXML private DatePicker dateBirth; 
	
	private ObservableList<Member> lists;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
//		button.setGraphic(value);
	}

	public void onMemberInsert(ActionEvent event) throws Exception{
        String id = tfId.getText().trim();
        String name = tfName.getText().trim();
        int kor = Integer.valueOf(tfKor.getText().trim());
        int eng = Integer.valueOf(tfEng.getText().trim());
        int math = Integer.valueOf(tfMath.getText().trim());
        int type = comboType.getSelectionModel().getSelectedIndex();        
        System.out.println( "MemberType : " + type );
        MemberType memtype = Utility.getMemType(type) ;
        
        if ( memtype == null ) {
			return ;
		}
        
        
        if( dateBirth.getValue() == null ) {
        	Alert alert = new Alert(AlertType.ERROR) ;
        	alert.setTitle("��¥ �����ϱ�");
        	alert.setHeaderText("��¥ ���� Ȯ��");
        	alert.setContentText("��¥�� �Է����ּ���.");
        	alert.showAndWait() ;
        	return ;
        }
        String birth = dateBirth.getValue().toString().replace("-", "/") ;
        
        Member bean = new Member(id, name, kor, eng, math, memtype, birth, null);
                
        MemberDao dao = new MemberDao();
        dao.insertData(bean) ;
        
        lists.add( bean ) ;
        
//        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fxml/SchoolBasic.fxml"));
//        Parent parent = fxmlLoader.load();
//        SchoolBasicController controller = fxmlLoader.<SchoolBasicController>getController();
//        controller.fillTableData( ) ;
        
        closeStage(event);
	}
    private void closeStage(ActionEvent event) {
        Node source = (Node)event.getSource(); 
        Stage stage = (Stage)source.getScene().getWindow();
        stage.close();
    }	

	public void xxx(ActionEvent e) {

	}

	public void setObservableList(ObservableList<Member> lists) {
		this.lists = lists ;		
	}
}