package schoolBasic;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Pagination;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Member;
import utility.Paging;

public class SchoolBasicController implements Initializable{
	@FXML private TableView<Member> tableView ;		
	@FXML private ComboBox<String> comboBox ;
	@FXML private Label pageStatus ;
	@FXML private VBox vbox ;
	@FXML private Pagination pagination ;	
	@FXML private ImageView imageView ;
	
	ObservableList<Member> dataLists = null ;

	MemberDao dao = new MemberDao() ;
	
	private final String DO_TOTAL_VIEW = "��ü ����" ;
	int totalcount = 0 ; //
	
	private void fillTableData( int beginRow, int endRow, int pageIndex , String pagingStatus) {
		System.out.println( "\nfillTableData �޼ҵ�");
		dataLists =  FXCollections.observableArrayList( dao.getAllData(beginRow - 1 , endRow) );
		System.out.println( "dataLists.size() : " + dataLists.size() );
		tableView.setItems( dataLists );
		pageStatus.setText(pagingStatus); 
	}	
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		comboBox.setValue( DO_TOTAL_VIEW );		
		setTableColumns() ;
		setPagination(0) ;
		setTableContextMenu() ;
		
		ChangeListener<Member> tableListener = new ChangeListener<Member>() {
			@Override
			public void changed(ObservableValue<? extends Member> observable, Member oldValue, Member newValue) {
				if ( newValue != null ) {
					String imagefile = "" ;
					Image someimage = null ;
					if( newValue.getImage() != null ) {
						imagefile = "/application/images/" + newValue.getImage()  ;
						System.out.println("�̹��� ���� : " +  imagefile);

						someimage = new Image(getClass().getResource(imagefile).toString()) ;
						imageView.setImage( someimage );	
					}else {
						imagefile = "/application/images/noimage.jpg" ;
						System.out.println("�̹��� ���� : " +  imagefile);

						someimage = new Image(getClass().getResource(imagefile).toString()) ;
						imageView.setImage( someimage );
					}
				}
			}
		};
		
		tableView.getSelectionModel().selectedItemProperty().addListener(tableListener);
	}
		
	private void setPagination( int pageIndex ) { //Pagination ���� ����
		System.out.println( "\nsetPagination �޼ҵ�");
		System.out.println( "pageIndex : " + pageIndex );
		pagination.setCurrentPageIndex(pageIndex);   
        pagination.setPageFactory(this::createPage);		
	} 

    private Node createPage(int pageIndex) {
    	System.out.println( "\ncreatePage �޼ҵ�");
    	System.out.println( "pageIndex : " + pageIndex );		

    	totalcount = dao.getTotalcount() ;
		System.out.println( "totalcount : " + totalcount );
        
    	Paging pageInfo = new Paging(String.valueOf( pageIndex + 1 ) , "10", this.totalcount, "url", null, null) ;
             
    	pagination.setPageCount( pageInfo.getTotalPage() );
        
    	int beginRow = pageInfo.getBeginRow();
    	int endRow = pageInfo.getEndRow() ;
    	System.out.println( "beginRow : " + beginRow );	
    	System.out.println( "endRow : " + endRow );	

    	String pagingStatus = pageInfo.getPagingStatus() ; 
    	fillTableData( beginRow, endRow, pageIndex, pagingStatus ) ;
    	vbox = new VBox(tableView) ;
    	
//        return null;  
        return vbox ;
    }
  		
	private void setTableContextMenu() {
		// ���̺� �信 ���ؽ�Ʈ �޴��� �����Ѵ�.
        ContextMenu contextMenu = new ContextMenu();
        MenuItem menuItem1 = new MenuItem("���� �׷���");
        MenuItem menuItem2 = new MenuItem("���� �׷���");
        MenuItem menuItem3 = new MenuItem("���� �׷���(��ü)");

        menuItem1.setOnAction((event) -> {
        	try {
        		makeBarChart() ;	
			} catch (Exception e) {}            
        });
        menuItem2.setOnAction((event) -> {
        	try {
        		makePieChart() ;	
			} catch (Exception e) {}        	
        });
        menuItem3.setOnAction((event) -> {
        	try {
        		makeBarChartAll() ;	
			} catch (Exception e) {}        	
        });

//        contextMenu.getItems().addAll(menuItem1, menuItem2 );
        contextMenu.getItems().addAll(menuItem1, menuItem2, menuItem3 );

        tableView.setContextMenu(contextMenu);		
	}

	private void makeBarChart() throws IOException {
		System.out.println("���� �׷��� �׸���");	
		 
		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/schoolBasic/BarChart.fxml"));
		
		Parent parent = fxmlLoader.load();
		ChartBarController controller = fxmlLoader.<ChartBarController>getController();
		int idx = tableView.getSelectionModel().getSelectedIndex() ;
		controller.makeChart( dataLists.get( idx ) );
		
		Scene scene = new Scene(parent);
		Stage stage = new Stage();
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setScene(scene);
		stage.showAndWait();			
	}
	
	private void makeBarChartAll() throws IOException {
		System.out.println("���� �׷��� �׸���");		
		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/schoolBasic/BarChart.fxml"));
		
		Parent parent = fxmlLoader.load();
		ChartBarController controller = fxmlLoader.<ChartBarController>getController();
		controller.makeChartAllData( dataLists );
		
		Scene scene = new Scene(parent);
		Stage stage = new Stage();
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setScene(scene);
		stage.showAndWait();			
	}	

	private void makePieChart() throws IOException{
		System.out.println("���� �׷��� �׸���");
		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("PieChart.fxml"));
		System.out.println("a");
		Parent parent = fxmlLoader.load();
		System.out.println("d");
		ChartPieController controller = fxmlLoader.<ChartPieController>getController();
		System.out.println("b");
		int idx = tableView.getSelectionModel().getSelectedIndex() ;
//		System.out.println(dataLists.get( idx ) );
		System.out.println("c");
		controller.makePieChart( dataLists.get( idx ) );
		
		Scene scene = new Scene(parent);
		Stage stage = new Stage();
		System.out.println("c");
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setScene(scene);
		System.out.println("d");
		stage.showAndWait();	
		System.out.println("e");
	}
	
	public void onInsert(ActionEvent e) throws IOException { //��� ��ư Ŭ��
		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/schoolBasic/MemberInsert.fxml"));
		Parent parent = fxmlLoader.load();
		MemberInsertController controller = fxmlLoader.<MemberInsertController>getController();
		controller.setObservableList( dataLists );

		Scene scene = new Scene(parent);
		Stage stage = new Stage();
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setScene(scene);
		stage.showAndWait();		
	}
	public void onClosing(ActionEvent e) throws IOException { //�����ϱ�
		System.out.println( "���α׷��� �����մϴ�." );
		Platform.exit();
	}
	
	@FXML private Button btnSaveFile ;
	
	public void onSaveFile(ActionEvent e) throws IOException { //���Ϸ� �����ϱ�
		FileChooser fileChooser = new FileChooser();
		File file = fileChooser.showSaveDialog(btnSaveFile.getScene().getWindow());
		if (file != null) {
			FileWriter fw = null ;
	        BufferedWriter bw = null ;
	        try {
	            fw = new FileWriter( file ) ;
	            bw = new BufferedWriter( fw ) ;
	            
	            //���⼭ ���Ͽ� ����ϰ�
	            for(Member member : dataLists) {
	    			bw.write( member.toString() ) ;
	                bw.newLine() ; 
	    		}
	            System.out.println("���� ��� �Ϸ�");
	            
	        } catch (IOException e1) {
	            System.out.println("����� ���� �߻�");
	            e1.printStackTrace();
	 
	        } finally{
	            try {
	                if( bw != null){ bw.close(); }
	                if( fw != null){ fw.close(); }
	            } catch (IOException e2) {
	                e2.printStackTrace();
	            }
	        }  
		}
	}

	public void onDelete(ActionEvent e) throws IOException { //���� ��ư Ŭ��
		int idx = tableView.getSelectionModel().getSelectedIndex() ;
		if( idx >= 0 ) {
			System.out.println("���õ� ���� ��ȣ : " + idx );
			
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("���� Ȯ�� �޽���");
			alert.setHeaderText("������ �׸� �����ϱ� ��ȭ ����");
			alert.setContentText("�� �׸��� �����Ͻðڽ��ϱ�?");

			Optional<ButtonType> result = alert.showAndWait();
			if (result.get() == ButtonType.OK){
				String id = tableView.getSelectionModel().getSelectedItem().getId() ; 
			    this.dao.deleteData(id) ;
			    
			    this.dataLists.remove( idx ) ;
			} else {
				System.out.println("������ ����Ͽ����ϴ�."); 
			}		
		}else {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("������ ��� Ȯ��");
			alert.setHeaderText("���� ��� �̼���");
			alert.setContentText("������ ���� �������ּ���.");

			alert.showAndWait();			
		}
	}
	
	@FXML private Label lblChoice ;	
	public void choiceSelect(ActionEvent event) {
		if(dataLists != null) {
			String choice = comboBox.getSelectionModel().getSelectedItem() ;
//			System.out.println("[" + choice + "]");
			lblChoice.setText( choice );
	
			if (choice.equals( DO_TOTAL_VIEW )) {
				tableView.setItems( dataLists );
			} else {
				ArrayList<Member> sublists = new ArrayList<Member>() ;
				
				for (int i = 0; i < dataLists.size(); i++) {
					Member mem = dataLists.get(i) ;
//					System.out.println(mem.getMemtype());
					if( mem.getMemtype().equals( choice) ) {
						sublists.add( mem ) ;
					}
				}		
				ObservableList<Member> subData =  FXCollections.observableArrayList( sublists );
//				System.out.println( subData.size() );
				tableView.setItems( subData );
			}			
		}
	}
	
	public void onUpdate(ActionEvent e) throws IOException { //���� ��ư Ŭ��
		int idx = tableView.getSelectionModel().getSelectedIndex() ;		
		if( idx >= 0 ) {
			System.out.println("���õ� ���� ��ȣ : " + idx );
			
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/schoolBasic/MemberUpdate.fxml"));
			Parent parent = fxmlLoader.load();
			MemberUpdateController controller = fxmlLoader.<MemberUpdateController>getController();
			controller.setObservableList( dataLists );
			
			Member bean = tableView.getSelectionModel().getSelectedItem() ;
			controller.setBean( bean, idx );

			Scene scene = new Scene(parent);
			Stage stage = new Stage();
			stage.initModality(Modality.APPLICATION_MODAL);
			stage.setScene(scene);
			stage.showAndWait();			
		}else {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("������ ��� Ȯ��");
			alert.setHeaderText("���� ��� �̼���");
			alert.setContentText("������ ���� �������ּ���.");

			alert.showAndWait();			
		}
	}

	private void setTableColumns() {
		//���̺��� �� Į�� ������ ���ε��Ѵ�.
		String[] field = {"id", "name", "kor", "eng", "math", "memtype", "birth", "image"} ;
		String[] colname = {"id", "�̸�", "����", "����", "����", "��� Ÿ��", "����", "����"} ;
		TableColumn tcol ;
		for (int i = 0; i < field.length; i++) {
			tcol = tableView.getColumns().get(i) ;
			tcol.setText( colname[i] );
			tcol.setCellValueFactory(new PropertyValueFactory(field[i]));
			tcol.setStyle("-fx-alignment:center;");
		}
	}
}