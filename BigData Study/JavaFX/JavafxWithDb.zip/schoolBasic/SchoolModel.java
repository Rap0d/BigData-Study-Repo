package schoolBasic;

import java.util.ArrayList;
import java.util.List;
 
public class SchoolModel { 
    public static List<Member> lists = new ArrayList<Member>();   
}